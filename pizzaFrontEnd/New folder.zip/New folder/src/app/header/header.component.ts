import { Component, OnInit  } from '@angular/core';
import { PizzeriaService } from '../pizzeria.service';
import { SessionStorageService, SessionStorage } from 'angular-web-storage'

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit  {
  isUserLoggedIn:any;
  constructor(private service: PizzeriaService,public session: SessionStorageService){}
  
  userLogout(){
    this.service.isUserLoggedIn=false;
    this.service.loggedInUser=''
    this.isUserLoggedIn=false
    window.location.reload();
  }

  ngOnInit(): void {
    this.isUserLoggedIn  = this.service.isUserLoggedIn
  }


}
