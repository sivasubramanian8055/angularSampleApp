import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class PizzeriaService {
  loggedInUser:any ='';
  isUserLoggedIn:any = false;
  constructor(private client: HttpClient) { }

  getMenu() {
    return this.client.get("http://localhost:3200/getMenu");
  }

  getIngridients() {
    return this.client.get("http://localhost:3200//getIngridents");
  }

  validateUser(userName:any,password:any){
    var body={
      userName:userName,
      password:password,
    }
    return this.client.post("http://localhost:3200/validateUser",body,{responseType: 'text'});
  }
  signUpUser(userName:any,password:any, email:any, phoneNumber:any){
    var body={
        userName: userName,
        password: password,
        email: email,
        phoneNumber: phoneNumber
    }
    // console.log(body)
    return this.client.post("http://localhost:3200/addUser",body,{responseType: 'text'});
  }

}
