import { Component, OnInit } from '@angular/core';
import { PizzeriaService } from '../pizzeria.service';

@Component({
  selector: 'app-order-pizza',
  templateUrl: './order-pizza.component.html',
  styleUrls: ['./order-pizza.component.css']
})
export class OrderPizzaComponent implements OnInit {
  userName:any;
  isUserLoggedIn:any;
  constructor(private service: PizzeriaService) { }

  ngOnInit(): void {
    this.userName = this.service.loggedInUser
    this.isUserLoggedIn = this.service.isUserLoggedIn
  }

}
