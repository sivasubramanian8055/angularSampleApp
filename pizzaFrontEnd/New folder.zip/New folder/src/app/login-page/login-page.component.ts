import { Component, OnInit  } from '@angular/core';
import { PizzeriaService } from '../pizzeria.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LoginPageComponent implements OnInit {
  userName:any;
  password:any;
  signUpUsername:any;
  signUpPassword:any;
  signUpEmail:any;
  signUpPhoneNumber:any;
  constructor(private service: PizzeriaService,private router: Router) { 

  }
  
  ngOnInit(): void {
  }

  addNewUser(){
    this.service.signUpUser(this.signUpUsername,this.signUpPassword,this.signUpEmail,this.signUpPhoneNumber).subscribe((response)=>{
      if(response==='user created successfully'){
        window.location.reload();
      }
    })
  }

  validateUser(){
    this.service.validateUser(this.userName,this.password).subscribe((response)=>{
      if(response === "validation sucessfull"){
        this.service.loggedInUser = this.userName
        this.service.isUserLoggedIn = true
        this.router.navigate(['/home']);
      }
      else{
        this.userName=''
      }
      this.password=''
    })
  }
}
